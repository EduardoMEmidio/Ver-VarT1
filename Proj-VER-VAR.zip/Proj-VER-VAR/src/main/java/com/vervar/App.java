package com.vervar;

public class App {
    public static void main(String[] args) {
        System.out.println("Projeto Ver-VarTI iniciado!");
    }
}
