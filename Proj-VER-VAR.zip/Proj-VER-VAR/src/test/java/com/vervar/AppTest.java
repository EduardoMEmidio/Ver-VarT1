package com.vervar;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AppTest {

    @Test
    public void testAppMain() {
        assertEquals(1, 1); // Teste básico
    }
}
